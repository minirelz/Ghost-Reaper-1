
from django.contrib import admin
from django.urls import path
from core.views import *
from django.contrib.auth.views import LoginView


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name="home"),
    path('login', login),
    path('register', register),
    path('carrito', carrito),
]
