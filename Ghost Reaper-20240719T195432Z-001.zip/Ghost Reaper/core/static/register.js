function validarUsuario() {
    let user = document.querySelector("#user");
    if(user.value.length >= 6){
        user.classList.add("correct");
        user.classList.remove("incorrect");
        document.querySelector("#error-user").innerHTML = "&nbsp;";
    }else{
        user.classList.add("incorrect");
        user.classList.remove("correct");
        document.querySelector("#error-user").innerHTML = "Error, ingrese minimo 6 caracteres!";
    }
}

function validarNusuario() {
    let nuser = document.querySelector("#nuser");
    if(nuser.value.length >= 6){
        nuser.classList.add("correct");
        nuser.classList.remove("incorrect");
        document.querySelector("#error-nuser").innerHTML = "&nbsp;";
    }else{
        nuser.classList.add("incorrect");
        nuser.classList.remove("correct");
        document.querySelector("#error-nuser").innerHTML = "Error, ingrese minimo 6 caracteres!";
    }
}

function validarContrasena() {
    let contra = document.querySelector("#contra");
    let confcontra = document.querySelector("#confcontra");
    if(contra.value == confcontra.value){
        confcontra.classList.add("correct");
        confcontra.classList.remove("incorrect");
        contra.classList.add("correct");
        contra.classList.remove("incorrect");
        document.querySelector("#error-contra").innerHTML = "&nbsp;";
    }else{
        confcontra.classList.add("incorrect");
        confcontra.classList.remove("correct");
        contra.classList.add("incorrect");
        contra.classList.remove("correct");
        document.querySelector("#error-contra").innerHTML = "Error, las contraseñas deben ser iguales!";
    }
}